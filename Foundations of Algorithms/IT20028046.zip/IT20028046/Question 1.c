//IT20028046

#include <stdio.h>
#include <string.h>


void f1(int l,char s[100]) //create function for remove duplicate elements
{
    for (int i = 0; i < l; ++i) //find duplicate elements and replace them with ' '
    {
        for (int j = i+1; j <l ; ++j) {
            if(s[i]==s[j])
            {
                s[j]=' ';

            }
        }
    }
    for (int i = 0; i < l; ++i) //remove spaces and print rest
    {
        if(s[i]!=' ')
            printf("%c",s[i]);
    }
}


int main() {
    //define variables
    int n, count = 0;
    char s[100];

    printf("input the string :"); //get user input
    scanf("%s",s);
    n= strlen(s); //assign array length to n

    for (int i = 0; i < n; ++i) //check elements only in lowercase format
    {
        if (s[i] >= 'A' && s[i] <= 'Z') {
            printf("!! only accept lowercase letters !!");
            count++;
        }
    }

    if(count<=0) //if all the elements in lowercase call function f1
        f1(n,s);

    return 0;
}
