//IT20028046

#include <stdio.h>
#include <string.h>

int main() {
    char array[3][10];
    char *a = NULL;
    char b[10];
    char c[10];
    int rev,m,n, counter = 0;

    printf("input number of passwords :");//get user inputs
    scanf("%d",&n);
    for (int i = 0; i < n; ++i) //store strings inside a 2d array
    {
        scanf("%s",array[i]);
    }
    for (int i = 0; i < n; ++i) //check all the strings consist with odd number of elements
    {
        a=array[i];
        if(strlen(a)%2==0)
        {
            printf("wrong length !!it must be odd no!!");
            counter++;
            break;
        }

    }
    if(counter<=0){
        for (int i = 0; i < n; ++i) {
            a=array[i];
            strcpy(b,a);
            strrev(a);
            rev = strcmp(a,b);
            if(rev==0) //check for palindrome
            {
                m= (strlen(a))/2;
                printf("%d %c\n\n",strlen(a),a[m]);
                break;
            }
            else
            {
                if(a==array[i])//check for reversed string
                {
                    strcpy(c,array[i]);
                    m= (strlen(c))/2;
                    printf("%d %c",(strlen(c)),c[m]);
                    break;
                }
            }
        }
    }
    return 0;
}