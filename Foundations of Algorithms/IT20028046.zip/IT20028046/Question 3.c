//IT20028046

#include <stdio.h>
#include <string.h>

void f1(int l,char a[100],char b[100])//create a function to left rotate the array elements
{
    char temp[100];
    for (int j = 1; j <=l ; ++j) {
        temp[0]=a[0];
        for (int i = 0; i <l-1 ; ++i) {
            a[i]=a[i+1];
        }
        a[l-1]=temp[0];


        if(strcmp(a,b)==0)//check b array is equal to the rotated array
            printf("%d",j);

    }
}

int main() {

    //define variables
    int l,c;
    char a[100];
    char b[100];


    printf("input the length of the two strings :");//get the length of two strings as a input
    scanf("%d",&l);

    if (l>1 && l<100) //check the length
    {
        for (int i = 0; i < 1; ++i) {

            printf("input S string  :");//get S string as an input
            scanf("%s", a);

            printf("input T string  :");//get T string as an input
            scanf("%s", b);
            //check the given strings have l number of elements
            if(strlen(b)!=l || strlen(a)!=l){
                printf("not match with the given length");
                break;
            }else
                c++;
        }
    }else
        printf("length error");

    if(c>0) //if the length is correct call the function
        f1(l, a, b);


    return 0;
}
